class input1{
	public static void main(String[] args){
		A a;
		A b;
		int z;
		a = new A();
		b = new A();
		/* a alias? b */
		z=1;
	}
}
class A{
	int dummy;
}
