class input1 {
    public static void main(String[] args) {
        A a1;
        B a2;

        a1 = new A();
        a2 = new B();

        /* a1 alias? a2 */

        {}
    }
}

class A {
}

class B {
}