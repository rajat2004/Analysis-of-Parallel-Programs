class Input1 {
	public static void main(String[] args) {
		try {
			int res;
			A a;
			ThreadX t1;
			
			/* L1: */ a = new A();
			t1 = new ThreadX();
			
			t1.start();
			
			/* L2: */ res = 0;
			
			t1.join();
			
			/* L3: */ res = 1;
			
			System.out.println(res);
		}
		catch(Exception e) {
		}
	}
}

class A {
}

class ThreadX extends Thread {
	public void run() {
		try {
			int x;
			
			/* L4: */ x = 1;
		} catch (Exception e) {
		}
	}
}

/* L1 mhp? L2 */
// No - sequential
/* L1 mhp? L4 */
// No - thread not started
/* L2 mhp? L4 */
// Yes - Thread started
/* L3 mhp? L4 */
// No - thread finished
