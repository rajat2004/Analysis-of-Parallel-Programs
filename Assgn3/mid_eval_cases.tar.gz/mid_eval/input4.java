class Input4 {
	public static void main(String[] args) {
		try {
			int res;
			A a;
			ThreadX t1;
			ThreadY t2;
			
			a = new A();
			t1 = new ThreadX();
			t2 = new ThreadY();

			t1.obj = a;
			t2.obj = a;
			
			t1.start();
			t2.start();
			
			t1.join();
			t2.join();
			
			res = 4;
			System.out.println(res);
		}
		catch(Exception e) {
		}
	}
}

class A{
}


class ThreadX extends Thread {
	A obj;
	
	public void run() {
		try {
			int x;
			/* L1: */ x = 1;
			
			synchronized(obj) {
				/* L2: */ x = 2;
			}
			
		} catch (Exception e) {
		}
	}
}

class ThreadY extends Thread {
	A obj;
	
	public void run() {
		try {
			int y;
			/* L3: */ y = 3;
			
			synchronized(obj) {
				/* L4: */ y = 4;
			}
		} catch (Exception e) {
		}
	}
}

/* L1 mhp? L2 */ // No
/* L1 mhp? L3 */ // Yes
/* L1 mhp? L4 */ // Yes
/* L2 mhp? L3 */ // Yes
/* L2 mhp? L4 */ // No
