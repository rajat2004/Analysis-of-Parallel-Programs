class Input2 {
	public static void main(String[] args) {
		try {
			int res;
			ThreadX t1;
			ThreadY t2;
			
			t1 = new ThreadX();
			t2 = new ThreadY();
			
			t1.start();
			t2.start();
			
			t1.join();
			t2.join();
			
			/* L3: */ res = 2;
			System.out.println(res);
		}
		catch(Exception e) {
		}
	}
}


class ThreadX extends Thread {
	public void run() {
		try {
			int x;
			/* L1: */ x = 2;
		} catch (Exception e) {
		}
	}
}

class ThreadY extends Thread {
	public void run() {
		try {
			int y;
			/* L2: */ y = 3;
		} catch (Exception e) {
		}
	}
}

/* L1 mhp? L2 */
// Yes
/* L3 mhp? L1 */
// No
