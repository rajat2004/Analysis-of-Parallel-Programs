class Input3 {
	public static void main(String[] args) {
		try {
			int res;
			ThreadX t1;
			ThreadY t2;
			ThreadZ t3;
			
			t1 = new ThreadX();
			t2 = new ThreadY();
			t3 = new ThreadZ();
			
			t3.start();
			t3.join();
			
			t1.start();
			/* L4: */ t2.start();
			
			t1.join();
			t2.join();
			
			res = 3;
			System.out.println(res);
		}
		catch(Exception e) {
		}
	}
}


class ThreadX extends Thread {
	public void run() {
		try {
			int x;
			/* L1: */ x = 2;
		} catch (Exception e) {
		}
	}
}

class ThreadY extends Thread {
	public void run() {
		try {
			int y;
			/* L2: */ y = 3;
		} catch (Exception e) {
		}
	}
}

class ThreadZ extends Thread {
	public void run() {
		try {
			int z;
			/* L3: */ z = 4;
		} catch (Exception e) {
		}
	}
}

/* L1 mhp? L2 */
// Yes 
/* L1 mhp? L3 */
// No - t3 has ended
/* L2 mhp? L3 */
// No - t3 has ended
/* L1 mhp? L4 */
// Yes
