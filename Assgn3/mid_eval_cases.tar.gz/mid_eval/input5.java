class Input5 {
	public static void main(String[] args) {
		try {
			int res;
			A a;
			boolean b;
			ThreadX t1;
			int tmp;
			
			a = new A();
			res = 0;
			a.count = res;
			
			t1 = new ThreadX();
			t1.a = a;
			
			t1.start();

			/* L5: */	tmp = 1;
			synchronized(a) {
				/* L6: */ res = a.count;
				b = res < tmp;
				while(b) {
					/* L7: */ a.wait();
				}
			}
			
			t1.join();

			
			res = 5;
			System.out.println(res);
		}
		catch(Exception e) {
		}
	}
}

class A {
	int count;
}


class ThreadX extends Thread {
	A a;
	
	public void run() {
		try {
			int x;
			boolean b;
			
			/* L1: */ x = 1;
			
			synchronized(a) {
				/* L2: */ x = 2;
			}
			
			synchronized(a) {
				/* L3: */ a.count = x;
				/* L4: */ a.notifyAll();
			}
		} catch (Exception e) {
		}
	}
}

/* L1 mhp? L2 */
// No - sequential
/* L1 mhp? L5 */
// Yes - Thread has started, not synch
/* L1 mhp? L6 */
// Yes, L1 is not synch
/* L2 mhp? L6 */
// No, both are sync
/* L3 mhp? L6 */
// No, both are sync
/* L4 mhp? L7 */
// Yes - If WAITING node is taken
// No - If WAIT node is taken 
